gcc ./main.c -o ./main.exe -I./include -L./lib -lraylib -lopengl32 -lgdi32 -lwinmm
./main.exe